# Notes

In the customer data *nrs* refers to the [NRS Social Rating](https://en.wikipedia.org/wiki/NRS_social_grade)

These phone numbers are based on [Irish phone numbers](https://en.wikipedia.org/wiki/Telephone_numbers_in_the_Republic_of_Ireland)
